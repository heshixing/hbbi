# 智能BI数据分析平台

### 前端
1. React 18
2. Umi 4 前端框架
3. Ant Design Pro 5.x 脚手架
4. Ant Design 组件库
5. OpenAPI 代码生成：自动生成后端调用代码
6. EChart 图表生成


### 后端

1. Java Spring Boot
2. MySQL数据库
3. Redis：Redissson限流控制
4. MyBatis-Plus 数据库访问结构 + MyBatisX ： 根据数据库表自动生成
5. RabbitMQ：消息队列
6. AI SDK：AI接口开发
7. JDK 线程池及异步化
8. Easy Excel：表格数据处理
9. Swagger + Knife4j 项目文档
10. Hutool 、Apache Common Utils等工具库


## BI项目展示
### 登录页展示
![](images/img_6.png)

***

### 注册页展示

***

![](images/img_7.png)

***



### 首页展示

![](images/img_3.png)

![](images/img_4.png)



### 同步分析数据生成图表
![](images/img_2.png)



### 异步分析数据生成图表
![](images/img_1.png)



### 图表管理界面
![](images/img_8.png)
![](images/img_9.png)

### 用户管理页面
![](images/img.png)
![](images/img_5.png)






