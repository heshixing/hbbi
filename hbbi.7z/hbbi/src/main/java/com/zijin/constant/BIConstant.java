package com.zijin.constant;

public interface BIConstant {
     String BI_EXCHANGE_NANE="bi-exchange";
     String BI_QUEUE_NAME="bi-queue";
     String BI_ROUTINGKEY="bi-routingKey";
}
