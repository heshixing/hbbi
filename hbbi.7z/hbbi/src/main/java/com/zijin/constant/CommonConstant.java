package com.zijin.constant;

/**
 * 通用常量
 *
 *
 */
public interface CommonConstant {

    /**
     * 升序
     */
    String SORT_ORDER_ASC = "ascend";

    /**
     * 降序
     */
    String SORT_ORDER_DESC = " descend";
    /**
     * bi 模型id
     * */
    long BI_MODE_ID = 1673957535360561154L;
    
}
