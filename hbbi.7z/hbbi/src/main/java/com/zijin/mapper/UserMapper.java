package com.zijin.mapper;

import com.zijin.model.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity com.zijin.model.entity.User
 */
public interface UserMapper extends BaseMapper<User> {

}




